zip -x .git/\* -x gd\* -x test\* -x \*.zip -x releases/\* -r releases/GoogleDrive-VideoStream-$1.zip .

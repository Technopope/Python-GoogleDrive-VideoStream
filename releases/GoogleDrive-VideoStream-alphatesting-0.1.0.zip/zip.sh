zip -x \*.zip -x releases -r releases/GoogleDrive-VideoStream-alphatesting-$1.zip .
